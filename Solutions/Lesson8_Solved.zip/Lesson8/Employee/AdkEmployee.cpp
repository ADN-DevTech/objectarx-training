﻿// (C) Copyright 2002-2007 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- AdkEmployee.cpp : Implementation of AdkEmployee
//-----------------------------------------------------------------------------
#include "StdAfx.h"
#include "AdkEmployee.h"

//-----------------------------------------------------------------------------
Adesk::UInt32 AdkEmployee::kCurrentVersionNumber =1 ;

//-----------------------------------------------------------------------------
ACRX_DXF_DEFINE_MEMBERS (
	AdkEmployee, AcDbEllipse,
	AcDb::kDHL_CURRENT, AcDb::kMReleaseCurrent, 
	AcDbProxyEntity::kNoOperation, ADKEMPLOYEE,
EMPLOYEE
|Product Desc:     A description for your object
|Company:          Your company name
|WEB Address:      Your company WEB site address
)

//-----------------------------------------------------------------------------
//my code---begin---constructor updated-----
AdkEmployee::AdkEmployee()
	: AcDbEllipse(AcGePoint3d(), AcGeVector3d(0, 0, 1), AcGeVector3d(1, 0, 0), 1)
{
	// Initialize string pointers.
	m_firstName = m_lastName = NULL;
}
//my code---end--- 


//my code---begin---
Acad::ErrorStatus AdkEmployee::firstName(TCHAR*& firstName)
{
	assertReadEnabled();
	firstName = _tcsdup(m_firstName);
	return Acad::eOk;

}


Acad::ErrorStatus AdkEmployee::setFirstName(const TCHAR* firstName)
{

	assertWriteEnabled();
	if (m_firstName)
		free(m_firstName);
	m_firstName = _tcsdup(firstName);
	return Acad::eOk;

}

Acad::ErrorStatus AdkEmployee::setLastName(const TCHAR* lastName)
{
	assertWriteEnabled();
	if (m_lastName)
		free(m_lastName);
	m_lastName = _tcsdup(lastName);
	return Acad::eOk;

}

Acad::ErrorStatus AdkEmployee::lastName(TCHAR*& lastName)
{
	assertReadEnabled();
	lastName = _tcsdup(m_lastName);
	return Acad::eOk;

}

Acad::ErrorStatus AdkEmployee::setID(const Adesk::Int32 ID)
{
	assertWriteEnabled();
	m_ID = ID;
	return Acad::eOk;
}

Acad::ErrorStatus AdkEmployee::iD(Adesk::Int32& ID)
{
	assertReadEnabled();
	ID = m_ID;
	return Acad::eOk;

}

Acad::ErrorStatus AdkEmployee::setCube(const Adesk::Int32 cube)
{
	assertWriteEnabled();
	m_cube = cube;
	return Acad::eOk;
}

Acad::ErrorStatus AdkEmployee::cube(Adesk::Int32& cube)
{
	assertReadEnabled();
	cube = m_cube;
	return Acad::eOk;
}

//my code---end---





AdkEmployee::~AdkEmployee () {
}

//-----------------------------------------------------------------------------
//----- AcDbObject protocols
//- Dwg Filing protocol
Acad::ErrorStatus AdkEmployee::dwgOutFields (AcDbDwgFiler *pFiler) const {
	assertReadEnabled () ;
	//----- Save parent class information first.
	Acad::ErrorStatus es =AcDbEllipse::dwgOutFields (pFiler) ;
	if ( es != Acad::eOk )
		return (es) ;
	//----- Object version number needs to be saved first
	if ( (es =pFiler->writeUInt32 (AdkEmployee::kCurrentVersionNumber)) != Acad::eOk )
		return (es) ;
	//----- Output params
	if ( (es =pFiler->writeInt32 (m_ID)) != Acad::eOk )
		return (es) ;
	if ( (es =pFiler->writeInt32 (m_cube)) != Acad::eOk )
		return (es) ;
	if ( (es =pFiler->writeString (m_firstName ? m_firstName : _T(""))) != Acad::eOk )
		return (es) ;
	if ( (es =pFiler->writeString (m_lastName ? m_lastName : _T(""))) != Acad::eOk )
		return (es) ;

	return (pFiler->filerStatus ()) ;
}

Acad::ErrorStatus AdkEmployee::dwgInFields (AcDbDwgFiler *pFiler) {
	assertWriteEnabled () ;
	//----- Read parent class information first.
	Acad::ErrorStatus es =AcDbEllipse::dwgInFields (pFiler) ;
	if ( es != Acad::eOk )
		return (es) ;
	//----- Object version number needs to be read first
	Adesk::UInt32 version =0 ;
	if ( (es =pFiler->readUInt32 (&version)) != Acad::eOk )
		return (es) ;
	if ( version > AdkEmployee::kCurrentVersionNumber )
		return (Acad::eMakeMeProxy) ;
	//- Uncomment the 2 following lines if your current object implementation cannot
	//- support previous version of that object.
	//if ( version < AdkEmployee::kCurrentVersionNumber )
	//	return (Acad::eMakeMeProxy) ;
	//----- Read params
	if ( (es =pFiler->readInt32 (&m_ID)) != Acad::eOk )
		return (es) ;
	if ( (es =pFiler->readInt32 (&m_cube)) != Acad::eOk )
		return (es) ;
	AcString firstName ;
	if ( (es =pFiler->readString (firstName)) != Acad::eOk )
		return (es) ;
	setFirstName (firstName.kACharPtr ()) ;
	AcString lastName ;
	if ( (es =pFiler->readString (lastName)) != Acad::eOk )
		return (es) ;
	setLastName (lastName.kACharPtr ()) ;

	return (pFiler->filerStatus ()) ;
}

//- Dxf Filing protocol
Acad::ErrorStatus AdkEmployee::dxfOutFields (AcDbDxfFiler *pFiler) const {
	assertReadEnabled () ;
	//----- Save parent class information first.
	Acad::ErrorStatus es =AcDbEllipse::dxfOutFields (pFiler) ;
	if ( es != Acad::eOk )
		return (es) ;
	es =pFiler->writeItem (AcDb::kDxfSubclass, _RXST("AdkEmployee")) ;
	if ( es != Acad::eOk )
		return (es) ;
	//----- Object version number needs to be saved first
	if ( (es =pFiler->writeUInt32 (kDxfInt32, AdkEmployee::kCurrentVersionNumber)) != Acad::eOk )
		return (es) ;
	//----- Output params
	//----- Group codes 90/91/1/2 are our own private codes within this
	//----- subclass's DXF block; see the matching switch in dxfInFields.
	if ( (es =pFiler->writeInt32 (kDxfInt32, m_ID)) != Acad::eOk )
		return (es) ;
	if ( (es =pFiler->writeInt32 (91, m_cube)) != Acad::eOk )
		return (es) ;
	if ( (es =pFiler->writeString (1, m_firstName ? m_firstName : _T(""))) != Acad::eOk )
		return (es) ;
	if ( (es =pFiler->writeString (2, m_lastName ? m_lastName : _T(""))) != Acad::eOk )
		return (es) ;

	return (pFiler->filerStatus ()) ;
}

Acad::ErrorStatus AdkEmployee::dxfInFields (AcDbDxfFiler *pFiler) {
	assertWriteEnabled () ;
	//----- Read parent class information first.
	Acad::ErrorStatus es =AcDbEllipse::dxfInFields (pFiler) ;
	if ( es != Acad::eOk || !pFiler->atSubclassData (_RXST("AdkEmployee")) )
		return (pFiler->filerStatus ()) ;
	//----- Object version number needs to be read first
	struct resbuf rb ;
	pFiler->readItem (&rb) ;
	if ( rb.restype != AcDb::kDxfInt32 ) {
		pFiler->pushBackItem () ;
		pFiler->setError (Acad::eInvalidDxfCode, _RXST("\nError: expected group code %d (version #)"), AcDb::kDxfInt32) ;
		return (pFiler->filerStatus ()) ;
	}
	Adesk::UInt32 version =(Adesk::UInt32)rb.resval.rlong ;
	if ( version > AdkEmployee::kCurrentVersionNumber )
		return (Acad::eMakeMeProxy) ;
	//- Uncomment the 2 following lines if your current object implementation cannot
	//- support previous version of that object.
	//if ( version < AdkEmployee::kCurrentVersionNumber )
	//	return (Acad::eMakeMeProxy) ;
	//----- Read params in non order dependant manner
	while ( es == Acad::eOk && (es =pFiler->readResBuf (&rb)) == Acad::eOk ) {
		switch ( rb.restype ) {
			//----- Read params by looking at their DXF code
			//----- (must match the codes used in dxfOutFields above)
			case kDxfInt32:
				m_ID =rb.resval.rlong ;
				break ;

			case 91:
				m_cube =rb.resval.rlong ;
				break ;

			case 1:
				setFirstName (rb.resval.rstring) ;
				break ;

			case 2:
				setLastName (rb.resval.rstring) ;
				break ;

			default:
				//----- An unrecognized group. Push it back so that the subclass can read it again.
				pFiler->pushBackItem () ;
				es =Acad::eEndOfFile ;
				break ;
		}
	}
	//----- At this point the es variable must contain eEndOfFile
	//----- - either from readResBuf() or from pushback. If not,
	//----- it indicates that an error happened and we should
	//----- return immediately.
	if ( es != Acad::eEndOfFile )
		return (Acad::eInvalidResBuf) ;

	return (pFiler->filerStatus ()) ;
}

//-----------------------------------------------------------------------------
//----- AcDbEntity protocols
Adesk::Boolean AdkEmployee::subWorldDraw (AcGiWorldDraw *mode) {
	assertReadEnabled () ;

	// Draw the ellipse first (base class behavior).
	AcDbEllipse::subWorldDraw(mode);

	//my code---begin---
	TCHAR buffer[255];
	_stprintf(buffer, _T("%d (cubicle: %d)"), m_ID, m_cube);
	mode->geometry().text(center(), normal(), majorAxis(), minorAxis().length() / 2, 1.0, 0.0, buffer);

	_stprintf(buffer, _T("%s %s"), m_firstName, m_lastName);
	mode->geometry().text(center() - minorAxis() / 2, normal(), majorAxis(), minorAxis().length() / 2, 1.0, 0.0, buffer);
	//my code---end---
	return (AcDbEllipse::subWorldDraw (mode)) ;
}


Adesk::UInt32 AdkEmployee::subSetAttributes (AcGiDrawableTraits *traits) {
	assertReadEnabled () ;
	return (AcDbEllipse::subSetAttributes (traits)) ;
}


