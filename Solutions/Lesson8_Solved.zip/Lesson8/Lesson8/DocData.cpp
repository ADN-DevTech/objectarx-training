﻿// (C) Copyright 2002-2012 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- DocData.cpp : Implementation file
//-----------------------------------------------------------------------------
#include "StdAfx.h"
#include "tchar.h"
#include "DocData.h"

//-----------------------------------------------------------------------------
//----- The one and only document manager object. You can use the DocVars object to retrieve
//----- document specific data throughout your application
AcApDataManager<CDocData> DocVars ;

//-----------------------------------------------------------------------------
//----- Implementation of the document data class.
CDocData::CDocData()
{
	//my code---begin---
    m_editCommand = false;
    m_doRepositioning = false;
}

//-----------------------------------------------------------------------------
CDocData::CDocData (const CDocData &data) {
}

//-----------------------------------------------------------------------------
CDocData::~CDocData () {
}


//my code---begin---
Acad::ErrorStatus attachEmployeeReactorToAllEmployee(bool attach)
{
	Acad::ErrorStatus es;

	//1. Get the block table (AcDbDatabase::getBlockTable()). 
	AcDbBlockTable* pBlockTable;
	if ((es = acdbHostApplicationServices()->workingDatabase()->getBlockTable(pBlockTable, AcDb::kForRead)) != Acad::eOk)
	{
		return es;
	}

	//2. Get the model space record(AcDbBlockTable::getAt(), ACDB_MODEL_SPACE).
	AcDbBlockTableRecord* pBTRec;
	es = pBlockTable->getAt(ACDB_MODEL_SPACE, pBTRec, AcDb::kForRead);
	pBlockTable->close();

	if (es != Acad::eOk)
		return es;

	//3. Get a block table record iterator(AcDbBlockTableRecordIterator, 
	//AcDbBlockTableRecord::newIterator()).
	AcDbBlockTableRecordIterator* pIter;
	if ((es = pBTRec->newIterator(pIter)) != Acad::eOk)
	{
		pBTRec->close();
		return es;
	}

	//4. Iterate through the Model Space records and retrieve the entities
	// //(AcDbBlockTableRecordIterator::getEntity()).
	// //If the retrieved block reference entity is not an EMPLOYEE object, just 
	// //return.
	for (; !pIter->done(); pIter->step())
	{
		AcDbEntity* pEnt;
		es = pIter->getEntity(pEnt, AcDb::kForRead);

		AcDbBlockReference* pBlockRef = AcDbBlockReference::cast(pEnt);
		if (!pBlockRef)
		{
			pEnt->close();
			continue;
		}

		AcDbObjectId objId = pBlockRef->blockTableRecord();
		AcDbBlockTableRecord* pBTRec;

		if (acdbOpenAcDbObject((AcDbObject*&)pBTRec, objId, AcDb::kForRead) != Acad::eOk)
		{
			acutPrintf(_T("\nCannot open block table record!\n"));
			pEnt->close();
			break;
		}

		const TCHAR* blockName;
		pBTRec->getName(blockName);
		pBTRec->close();

		if (_tcscmp(blockName, _T("EMPLOYEE"))) {
			pEnt->close();
			continue; // Not an employee
		}

		//5. If the retrieved entity is an "EMPLOYEE" block reference, attach the 
	// //global object reactor(AcDbObject::addReactor()) or if the parameter 
	// //"attach" is false then remove the already attached object reactor
	// //(AcDbObject::removeReactor()).

		if (attach)
			pEnt->addReactor(pEmployeeReactor);
		else
			pEnt->removeReactor(pEmployeeReactor);

		//6. Finally, don't forget to delete the iterator and to close the objects.  
		pEnt->close();
	}

	delete pIter;
	pBTRec->close();

	return Acad::eOk;
}



//If you unload your application you must detach all object reactors attached to EMPLOYEE block reference entities. Implement detachAllEmployeeReactors() to do this. 
void detachAllEmployeeReactors()
{
	//1. Get an AcApDocumentIterator(acDocManager->newAcApDocumentIterator()).
	//acDocManager is a global macro that is used to retrieve the AcApDocManager which is responsible for all the 
	//documents in an AutoCAD session.Refer to the AcApDocManager in the ObjectARX online help for details.
	AcApDocumentIterator* pIter = acDocManager->newAcApDocumentIterator();
	if (pIter == NULL)
	{
		return;
	}

	//2. Store a pointer to the current document, so you can reset the document after iterating
	//(acDocManager->curDocument()).
	AcApDocument* pOldDoc = acDocManager->curDocument();

	//3. Iterate through all documents, make each document the current document and call 
	//attachEmployeeReactorToAllEmployee(false).
	while (!pIter->done())
	{
		AcApDocument* pDoc = pIter->document();

		if (pDoc->lockMode() == AcAp::kNone)
		{
			if (acDocManager->setCurDocument(pDoc, AcAp::kAutoWrite, Adesk::kFalse) == Acad::eOk)
			{
				attachEmployeeReactorToAllEmployee(false);
				acDocManager->unlockDocument(pDoc);
			}
		}
		else
		{
			acDocManager->setCurDocument(pDoc);
			attachEmployeeReactorToAllEmployee(false);
		}
		pIter->step();
	}
	delete pIter;

	//4. After iterating, reset the current document to be the one that was current before iterating.
	acDocManager->setCurDocument(pOldDoc, AcAp::kNone, Adesk::kFalse);
}

//my code---end---