﻿// (C) Copyright 2002-2007 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- AdkEdEmployeeReactor.cpp : Implementation of AdkEdEmployeeReactor
//-----------------------------------------------------------------------------
#include "StdAfx.h"
#include "AdkEdEmployeeReactor.h"
#include "tchar.h"

//-----------------------------------------------------------------------------
AdkEdEmployeeReactor::AdkEdEmployeeReactor (const bool autoInitAndRelease) : AcEditorReactor(), mbAutoInitAndRelease(autoInitAndRelease) {
	if ( autoInitAndRelease ) {
		if ( acedEditor )
			acedEditor->addReactor (this) ;
		else
			mbAutoInitAndRelease =false ;
	}
}

//-----------------------------------------------------------------------------
AdkEdEmployeeReactor::~AdkEdEmployeeReactor () {
	Detach () ;
}

//-----------------------------------------------------------------------------
void AdkEdEmployeeReactor::Attach () {
	Detach () ;
	if ( !mbAutoInitAndRelease ) {
		if ( acedEditor ) {
			acedEditor->addReactor (this) ;
			mbAutoInitAndRelease =true ;
		}
	}
}

void AdkEdEmployeeReactor::Detach () {
	if ( mbAutoInitAndRelease ) {
		if ( acedEditor ) {
			acedEditor->removeReactor (this) ;
			mbAutoInitAndRelease =false ;
		}
	}
}

AcEditor *AdkEdEmployeeReactor::Subject () const {
	return (acedEditor) ;
}

bool AdkEdEmployeeReactor::IsAttached () const {
	return (mbAutoInitAndRelease) ;
}

//my code---begin---
void AdkEdEmployeeReactor::commandWillStart(const ACHAR* cmdStr)

{
	//1. Check if one of the commands "MOVE", "ROTATE", "STRETCH", "SCALE" or "GRIP_STRETCH" is started (use a string comparison function such as strcmp() current command being used is passed in through the parameter). 

	if (_tcscmp(cmdStr, _T("MOVE")) && _tcscmp(cmdStr, _T("ROTATE"))
		&& _tcscmp(cmdStr, _T("SCALE")) && _tcscmp(cmdStr, _T("STRETCH"))
		&& _tcscmp(cmdStr, _T("GRIP_STRETCH")))
	{
		acutPrintf(_T("\nNone of MOVE, ROTATE, STRETCH, SCALE or GRIP_STRETCH is started..No Action!!\n"));
		return;
	}
	//2. If it is one of the monitored commands, set m_editCommand = true;and m_doRepositioning = false; (Use DocVars.docData().<appropriate variable here>).
	DocVars.docData().m_editCommand = true;
	DocVars.docData().m_doRepositioning = false;

	//3. Reset any objectIdsand position information(AcDbObjectIdArray::setLogicalLength()) to zero.
	DocVars.docData().m_changedObjects.setLogicalLength(0);
	DocVars.docData().m_employeePositions.setLogicalLength(0);

}

void AdkEdEmployeeReactor::commandEnded(const ACHAR * cmdStr)

{
	//1. If the command being monitored is not a monitored command from the 
	// above list of commands then set m_editCommand = false; and simply return. 
	if (DocVars.docData().m_editCommand == false)
	{
		acutPrintf(_T("\nNone of te monitored commands are active.. No action!\n"));
		return;
	}

	//2. Reset m_editCommand to false.
	DocVars.docData().m_editCommand = false;

	//3. Set m_doRepositioning to true and start repositioning the moved objects
	DocVars.docData().m_doRepositioning = true;

	//4. For every object in m_changedObjects(AcDbObjectIdArray::length()) do the following
	//4.1	Open the entity(acdbOpenObject()).
	AcDbBlockReference* pBlockRef;
	for (int i = 0; i < DocVars.docData().m_changedObjects.length(); ++i)
	{
		if (acdbOpenObject(pBlockRef, DocVars.docData().m_changedObjects.at(i), AcDb::kForWrite) == Acad::eOk)
		{
			//4.4.2	If the actual position is different from the stored position, 
			//m_employeePositions.at(), AcDbBlockReference::setPosition()).
			AcGePoint3d newPos = pBlockRef->position();
			AcGePoint3d oldPos = DocVars.docData().m_employeePositions.at(i);

			//reposition the object(AcDbBlockReference::position(), 
			if (newPos != oldPos)
			{
				pBlockRef->setPosition(oldPos);
				acutPrintf(_T("\nEmployee has been reset to original position!!\n"));
			}
			else
				acutPrintf(_T("\nNo change in Employee's original position.. No action!!\n"));
			pBlockRef->close();
		}
	}
}
