﻿// (C) Copyright 2002-2007 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- AdkEmployeeReactor.cpp : Implementation of AdkEmployeeReactor
//-----------------------------------------------------------------------------
#include "StdAfx.h"
#include "AdkEmployeeReactor.h"

//-----------------------------------------------------------------------------
ACRX_CONS_DEFINE_MEMBERS(AdkEmployeeReactor, AcDbObjectReactor, 1)

//-----------------------------------------------------------------------------
AdkEmployeeReactor::AdkEmployeeReactor () : AcDbObjectReactor() {
}

//-----------------------------------------------------------------------------
AdkEmployeeReactor::~AdkEmployeeReactor () {
}


//my code
void AdkEmployeeReactor::openedForModify(const AcDbObject* pObj)
{
	
	if (DocVars.docData().m_doRepositioning == true || DocVars.docData().m_editCommand == false)
	{
		acutPrintf(_T("\nCurrently repositioning/None of the edit commands are active.. No action from openedForModify()!!\n"));
		return;
	}
	

	//Verify that the AcDbObject passed in, is an AcDbBlockReference entity, 
	//if not return.
	AcDbBlockReference* pBlockRef = AcDbBlockReference::cast(pObj);
	if (!pBlockRef)
		return;

	// Retrieve the name of the AcDbBlockReference. For this you will need to get the 
	//AcDbBlockReferences block definition AcDbBlockTableRecord and query the 
	//name of the AcDbBlockTableRecord. 
	//(Use AcDbBlockReference::blockTableRecord ()). 
	//If it is not an EMPLOYEE block reference, just return. 
	AcDbObjectId objId = pBlockRef->blockTableRecord();    //get BTRec ID from Block Table

	AcDbBlockTableRecord* pBTRec;
	if (acdbOpenAcDbObject((AcDbObject*&)pBTRec, objId, AcDb::kForRead) != Acad::eOk)
	{
		acutPrintf(_T("\nFailed to open block table record. Aborting!!\n"));
		return;
	}
	const TCHAR* blockName;
	pBTRec->getName(blockName);
	pBTRec->close();

	if (_tcscmp(blockName, _T("EMPLOYEE"))) //returns 0 if identical >> that is false
		return; //not an EMPLOYEE block 

	//Store the position of the openedForModify() object in 
	//m_employeePositions(AcGePoint3dArray::append()).
	DocVars.docData().m_employeePositions.append(pBlockRef->position());

	//Store the objectId of the openedForModify() object in 
	//m_changedObjects(AcDbObjectIdArray::append()).
	DocVars.docData().m_changedObjects.append(pBlockRef->objectId());
}
