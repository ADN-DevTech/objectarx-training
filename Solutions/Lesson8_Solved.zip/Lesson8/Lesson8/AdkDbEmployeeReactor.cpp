﻿// (C) Copyright 2002-2007 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- AdkDbEmployeeReactor.cpp : Implementation of AdkDbEmployeeReactor
//-----------------------------------------------------------------------------
#include "StdAfx.h"
#include "AdkDbEmployeeReactor.h"

//-----------------------------------------------------------------------------
ACRX_CONS_DEFINE_MEMBERS(AdkDbEmployeeReactor, AcDbDatabaseReactor, 1)

//-----------------------------------------------------------------------------
AdkDbEmployeeReactor::AdkDbEmployeeReactor (AcDbDatabase *pDb) : AcDbDatabaseReactor(), mpDatabase(pDb) {
	if ( pDb )
		pDb->addReactor (this) ;
}

//-----------------------------------------------------------------------------
AdkDbEmployeeReactor::~AdkDbEmployeeReactor () {
	Detach () ;
}

//-----------------------------------------------------------------------------
void AdkDbEmployeeReactor::Attach (AcDbDatabase *pDb) {
	Detach () ;
	if ( mpDatabase == NULL ) {
		if ( (mpDatabase =pDb) != NULL )
			pDb->addReactor (this) ;
	}
}

void AdkDbEmployeeReactor::Detach () {
	if ( mpDatabase ) {
		mpDatabase->removeReactor (this) ;
		mpDatabase =NULL ;
	}
}

AcDbDatabase *AdkDbEmployeeReactor::Subject () const {
	return (mpDatabase) ;
}

bool AdkDbEmployeeReactor::IsAttached () const {
	return (mpDatabase != NULL) ;
}


//my code
void AdkDbEmployeeReactor::objectAppended(const AcDbDatabase* dbDwg, const AcDbObject* dbObj)
{
	//1. Check if the appended object is an 
	// AcDbBlockReference.If not return.
	AcDbBlockReference* pInsert = AcDbBlockReference::cast(dbObj);
	if (!pInsert)
		return;

	//2. Get the block table record of the reference. 
	// (AcDbBlockReference::blockTableRecord()).
	AcDbObjectId blockId = pInsert->blockTableRecord();
	AcDbBlockTableRecord* pBlockTableRecord;
	if (acdbOpenAcDbObject((AcDbObject*&)pBlockTableRecord, blockId, AcDb::kForRead) != Acad::eOk) {
		acutPrintf(_T("\nCannot open block table record!\n"));
		return;
	}

	//3. Get the name of the block table record and check 
	// if it is an EMPLOYEE block reference.If not return. (AcDbSymbolTable::getName()).
	const TCHAR* blockName;
	pBlockTableRecord->getName(blockName);
	pBlockTableRecord->close();

	if (_tcscmp(blockName, _T("EMPLOYEE")))
		return; // Not an employee

	//4. Attach the AdskEmployeeReactor object reactor to 
	// the appended block reference. 
	//(AcDbObject::addReactor()).
	//Remember we are watching the database to see if any 
	//EMPLOYEE block references are being addedand if so 
	//we are attaching the AdskEmployeeReactor 
	//object reactor to the block reference.
	dbObj->addReactor(pEmployeeReactor);
}
