﻿// (C) Copyright 2002-2012 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- acrxEntryPoint.cpp
//-----------------------------------------------------------------------------
#include "StdAfx.h"
#include "resource.h"
#include "utilities.h"
#include <tchar.h>

//-----------------------------------------------------------------------------
#define szRDS _RXST("Adk")

//-----------------------------------------------------------------------------
//----- ObjectARX EntryPoint
class CLesson6App : public AcRxArxApp {

public:
	CLesson6App () : AcRxArxApp () {}

	virtual AcRx::AppRetCode On_kInitAppMsg (void *pkt) {
		// TODO: Load dependencies here

		// You *must* call On_kInitAppMsg here
		AcRx::AppRetCode retCode =AcRxArxApp::On_kInitAppMsg (pkt) ;
		
		// TODO: Add your initialization code here

		return (retCode) ;
	}

	virtual AcRx::AppRetCode On_kUnloadAppMsg (void *pkt) {
		// TODO: Add your code here

		// You *must* call On_kUnloadAppMsg here
		AcRx::AppRetCode retCode =AcRxArxApp::On_kUnloadAppMsg (pkt) ;

		// TODO: Unload dependencies here

		return (retCode) ;
	}

	virtual void RegisterServerComponents () {
	}
	
	// The ACED_ARXCOMMAND_ENTRY_AUTO macro can be applied to any static member 
	// function of the CLesson6App class.
	// The function should take no arguments and return nothing.
	//
	// NOTE: ACED_ARXCOMMAND_ENTRY_AUTO has overloads where you can provide resourceid and
	// have arguments to define context and command mechanism.
	
	// ACED_ARXCOMMAND_ENTRY_AUTO(classname, group, globCmd, locCmd, cmdFlags, UIContext)
	// ACED_ARXCOMMAND_ENTRYBYID_AUTO(classname, group, globCmd, locCmdId, cmdFlags, UIContext)
	// only differs that it creates a localized name using a string in the resource file
	//   locCmdId - resource ID for localized command

	// Modal Command with localized name
	// ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkMyGroup, MyCommand, MyCommandLocal, ACRX_CMD_MODAL)
	static void AdkMyGroupMyCommand () {
		// Put your command code here

	}

	// Modal Command with pickfirst selection
	// ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkMyGroup, MyPickFirst, MyPickFirstLocal, ACRX_CMD_MODAL | ACRX_CMD_USEPICKSET)
	static void AdkMyGroupMyPickFirst () {
		ads_name result ;
		int iRet =acedSSGet (ACRX_T("_I"), NULL, NULL, NULL, result) ;
		if ( iRet == RTNORM )
		{
			// There are selected entities
			// Put your command using pickfirst set code here
		}
		else
		{
			// There are no selected entities
			// Put your command code here
		}
	}

	// Application Session Command with localized name
	// ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkMyGroup, MySessionCmd, MySessionCmdLocal, ACRX_CMD_MODAL | ACRX_CMD_SESSION)
	static void AdkMyGroupMySessionCmd () {
		// Put your command code here
	}

	// The ACED_ADSFUNCTION_ENTRY_AUTO / ACED_ADSCOMMAND_ENTRY_AUTO macros can be applied to any static member 
	// function of the CLesson6App class.
	// The function may or may not take arguments and have to return RTNORM, RTERROR, RTCAN, RTFAIL, RTREJ to AutoCAD, but use
	// acedRetNil, acedRetT, acedRetVoid, acedRetInt, acedRetReal, acedRetStr, acedRetPoint, acedRetName, acedRetList, acedRetVal to return
	// a value to the Lisp interpreter.
	//
	// NOTE: ACED_ADSFUNCTION_ENTRY_AUTO / ACED_ADSCOMMAND_ENTRY_AUTO has overloads where you can provide resourceid.
	
	//- ACED_ADSFUNCTION_ENTRY_AUTO(classname, name, regFunc) - this example
	//- ACED_ADSSYMBOL_ENTRYBYID_AUTO(classname, name, nameId, regFunc) - only differs that it creates a localized name using a string in the resource file
	//- ACED_ADSCOMMAND_ENTRY_AUTO(classname, name, regFunc) - a Lisp command (prefix C:)
	//- ACED_ADSCOMMAND_ENTRYBYID_AUTO(classname, name, nameId, regFunc) - only differs that it creates a localized name using a string in the resource file

	// Lisp Function is similar to ARX Command but it creates a lisp 
	// callable function. Many return types are supported not just string
	// or integer.
	// ACED_ADSFUNCTION_ENTRY_AUTO(CLesson6App, MyLispFunction, false)
	static int ads_MyLispFunction () {
		//struct resbuf *args =acedGetArgs () ;
		
		// Put your command code here

		//acutRelRb (args) ;
		
		// Return a value to the AutoCAD Lisp Interpreter
		// acedRetNil, acedRetT, acedRetVoid, acedRetInt, acedRetReal, acedRetStr, acedRetPoint, acedRetName, acedRetList, acedRetVal

		return (RTNORM) ;
	}
	



	// ---------myCode------------
	static void AdkLesson6_CREATE(void)
	{
		//1. The implementation will call our 
		// user defined utility function createLayer() 
		// with parameter "USER" as layer name and 
		// user defined function createBlockRecord() with 
		// parameter "EMPLOYEE" as block name. 

		AcDbObjectId layerId;
		if (createLayer(_T("USER"), layerId) != Acad::eOk)
		{
			acutPrintf(_T("\n Error:- Failed to create layer USER\n"));
			//return;
		}

		// This is not always needed, but a call to 'applyCurDwgLayerTableChanges()'
		// will synchronize the newly created layer table change with the 
		// rest of the current DWG database.

		//2. After the layer table changes, call the 
		//ObjectARX global function applyCurDwgLayerTableChanges().
		// This function will force AutoCAD to update itself 
		// to use any changes made to any layer table records 
		// in the drawing currently in the AutoCAD editor.
		//
		applyCurDwgLayerTableChanges();

		acutPrintf(_T("\nLayer USER successfully created.\n"));

		if (createBlockRecord(_T("EMPLOYEE")) != Acad::eOk)
			acutPrintf(_T("\nFailed to create block record EMPLOYEE\n"));
		else
			acutPrintf(_T("\nSuccessfully created block record EMPLOYEE\n"));
	}

	static void AdkLesson6_SETLAYER(void)
	{
		//1. Open the block table of the current working database
		Acad::ErrorStatus es;

		AcDbBlockTable* pBlockTable;

		es = acdbHostApplicationServices()->workingDatabase()->getBlockTable(pBlockTable, AcDb::kForRead);
		if (es != Acad::eOk)
		{
			acutPrintf(_T("\nFailed to open the Block Table"));
			return;
		}

		//2. Get the MODEL SPACE block table record 
		//(AcDbBlockTable::getAt(), ACDB_MODEL_SPACE ) 
		AcDbBlockTableRecord* pBTRec;
		es = pBlockTable->getAt(ACDB_MODEL_SPACE, pBTRec, AcDb::kForWrite);
		if (es != Acad::eOk)
		{
			acutPrintf(_T("Failed to Get the MODEL SPACE block table record"));
			pBlockTable->close();
			return;
		}
		pBlockTable->close();

		// 3. Obtain a block table record iterator 
		// (AcDbBlockTableRecordIterator, AcDbBlockTableRecord::newIterator()) 
		// to iterate through the MODEL SPACE block table record. 

		AcDbBlockTableRecordIterator* pBTItr;
		if ((es = pBTRec->newIterator(pBTItr)) != Acad::eOk)
		{
			acutPrintf(_T("\nFailed to create block table record iterator"));
			pBTRec->close();
			return;
		}

		// 4. Iterate through the MODEL_SPACE 
		// (AcDbBlockTableRecordIterator::start(), 
		// AcDbBlockTableRecordIterator::done(), 
		// AcDbBlockTableRecordIterator::step()). 

		AcDbEntity* pEnt;
		for (pBTItr->start(); !pBTItr->done(); pBTItr->step())
		{
			//5. To open objects for read or write operations 
			// use acdbOpenObject().
			//6. Obtain the entity(AcDbBlockTableRecordIterator::getEntity()).

			if ((es = pBTItr->getEntity(pEnt, AcDb::kForRead)) != Acad::eOk)
			{
				acutPrintf(_T("\nFailed to open entity through iterator"));
				continue;
			}
			//7. Check if the entity is a block reference
			// (pEnt->isA() != AcDbBlockReference::desc()).
			if (pEnt->isA() != AcDbBlockReference::desc())
			{
				pEnt->close();
				continue;
			}

			//8. Obtain the block table record of the reference
			// (AcDbBlockReference::blockTableRecord()) and 
			// check if the block table record's name is "EMPLOYEE". 

			TCHAR* blockName;
			AcDbBlockTableRecord* pCurEntBlock;
			AcDbObjectId blockId = (AcDbBlockReference::cast(pEnt))->blockTableRecord();
			if (acdbOpenObject((AcDbObject*&)pCurEntBlock, blockId, AcDb::kForRead) == Acad::eOk)
			{
				pCurEntBlock->getName(blockName);
				if (_tcscmp(blockName, _T("EMPLOYEE")) == 0)
				{
					if (pEnt->upgradeOpen() == Acad::eOk)
					{
						//9. Change the layer(setLayer())

						pEnt->setLayer(_T("USER"));
					}
				}
				pCurEntBlock->close();
				acdbFree(blockName);
			}

			//10.Don't forget to close any objects you opened 
			//   and delete the iterator ! 
			pEnt->close();

		}
		delete pBTItr;
		pBTRec->close();

	}
	// ---------myCode------------


} ;

//-----------------------------------------------------------------------------
IMPLEMENT_ARX_ENTRYPOINT(CLesson6App)

ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkMyGroup, MyCommand, MyCommandLocal, ACRX_CMD_MODAL, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkMyGroup, MyPickFirst, MyPickFirstLocal, ACRX_CMD_MODAL | ACRX_CMD_USEPICKSET, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkMyGroup, MySessionCmd, MySessionCmdLocal, ACRX_CMD_MODAL | ACRX_CMD_SESSION, NULL)
ACED_ADSSYMBOL_ENTRY_AUTO(CLesson6App, MyLispFunction, false)

ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkLesson6, _CREATE, CREATE, ACRX_CMD_TRANSPARENT, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkLesson6, _SETLAYER, SETLAYER, ACRX_CMD_TRANSPARENT, NULL)
