﻿// (C) Copyright 2002-2012 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- acrxEntryPoint.cpp
//-----------------------------------------------------------------------------
#include "StdAfx.h"
#include "resource.h"
#include "utilities.h"
#include <tchar.h>

//-----------------------------------------------------------------------------
#define szRDS _RXST("Adk")

//-----------------------------------------------------------------------------
//----- ObjectARX EntryPoint
class CLesson6App : public AcRxArxApp {

public:
	CLesson6App () : AcRxArxApp () {}

	virtual AcRx::AppRetCode On_kInitAppMsg (void *pkt) {
		// TODO: Load dependencies here
		//my code---begin---
		AcRxObject* pSvc;
		if (!(pSvc = acrxServiceDictionary->at(ADKEMPLOYEEDETAILS_DBXSERVICE)))
		{
			if (!acrxDynamicLinker->loadModule(ACRX_T("AdkEmployeeDetails.dbx"), 0))
			{
				acutPrintf(ACRX_T("\nUnable to load AdkEmployeeDetails.dbx. Unloading...\n"));
				return AcRx::kRetError;
			}
		}
		//my code---end---

		// You *must* call On_kInitAppMsg here
		AcRx::AppRetCode retCode =AcRxArxApp::On_kInitAppMsg (pkt) ;
		
		// TODO: Add your initialization code here

		return (retCode) ;
	}

	virtual AcRx::AppRetCode On_kUnloadAppMsg (void *pkt) {
		// TODO: Add your code here

		// You *must* call On_kUnloadAppMsg here
		AcRx::AppRetCode retCode =AcRxArxApp::On_kUnloadAppMsg (pkt) ;

		// TODO: Unload dependencies here

		return (retCode) ;
	}

	virtual void RegisterServerComponents () {
	}
	
	// The ACED_ARXCOMMAND_ENTRY_AUTO macro can be applied to any static member 
	// function of the CLesson6App class.
	// The function should take no arguments and return nothing.
	//
	// NOTE: ACED_ARXCOMMAND_ENTRY_AUTO has overloads where you can provide resourceid and
	// have arguments to define context and command mechanism.
	
	// ACED_ARXCOMMAND_ENTRY_AUTO(classname, group, globCmd, locCmd, cmdFlags, UIContext)
	// ACED_ARXCOMMAND_ENTRYBYID_AUTO(classname, group, globCmd, locCmdId, cmdFlags, UIContext)
	// only differs that it creates a localized name using a string in the resource file
	//   locCmdId - resource ID for localized command

	// Modal Command with localized name
	// ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkMyGroup, MyCommand, MyCommandLocal, ACRX_CMD_MODAL)
	static void AdkMyGroupMyCommand () {
		// Put your command code here

	}

	// Modal Command with pickfirst selection
	// ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkMyGroup, MyPickFirst, MyPickFirstLocal, ACRX_CMD_MODAL | ACRX_CMD_USEPICKSET)
	static void AdkMyGroupMyPickFirst () {
		ads_name result ;
		int iRet =acedSSGet (ACRX_T("_I"), NULL, NULL, NULL, result) ;
		if ( iRet == RTNORM )
		{
			// There are selected entities
			// Put your command using pickfirst set code here
		}
		else
		{
			// There are no selected entities
			// Put your command code here
		}
	}

	// Application Session Command with localized name
	// ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkMyGroup, MySessionCmd, MySessionCmdLocal, ACRX_CMD_MODAL | ACRX_CMD_SESSION)
	static void AdkMyGroupMySessionCmd () {
		// Put your command code here
	}

	// The ACED_ADSFUNCTION_ENTRY_AUTO / ACED_ADSCOMMAND_ENTRY_AUTO macros can be applied to any static member 
	// function of the CLesson6App class.
	// The function may or may not take arguments and have to return RTNORM, RTERROR, RTCAN, RTFAIL, RTREJ to AutoCAD, but use
	// acedRetNil, acedRetT, acedRetVoid, acedRetInt, acedRetReal, acedRetStr, acedRetPoint, acedRetName, acedRetList, acedRetVal to return
	// a value to the Lisp interpreter.
	//
	// NOTE: ACED_ADSFUNCTION_ENTRY_AUTO / ACED_ADSCOMMAND_ENTRY_AUTO has overloads where you can provide resourceid.
	
	//- ACED_ADSFUNCTION_ENTRY_AUTO(classname, name, regFunc) - this example
	//- ACED_ADSSYMBOL_ENTRYBYID_AUTO(classname, name, nameId, regFunc) - only differs that it creates a localized name using a string in the resource file
	//- ACED_ADSCOMMAND_ENTRY_AUTO(classname, name, regFunc) - a Lisp command (prefix C:)
	//- ACED_ADSCOMMAND_ENTRYBYID_AUTO(classname, name, nameId, regFunc) - only differs that it creates a localized name using a string in the resource file

	// Lisp Function is similar to ARX Command but it creates a lisp 
	// callable function. Many return types are supported not just string
	// or integer.
	// ACED_ADSFUNCTION_ENTRY_AUTO(CLesson6App, MyLispFunction, false)
	static int ads_MyLispFunction () {
		//struct resbuf *args =acedGetArgs () ;
		
		// Put your command code here

		//acutRelRb (args) ;
		
		// Return a value to the AutoCAD Lisp Interpreter
		// acedRetNil, acedRetT, acedRetVoid, acedRetInt, acedRetReal, acedRetStr, acedRetPoint, acedRetName, acedRetList, acedRetVal

		return (RTNORM) ;
	}
	



	// ---------myCode------------
	static void AdkLesson6_CREATE(void)
	{
		//1. The implementation will call our 
		// user defined utility function createLayer() 
		// with parameter "USER" as layer name and 
		// user defined function createBlockRecord() with 
		// parameter "EMPLOYEE" as block name. 

		AcDbObjectId layerId;
		if (createLayer(_T("USER"), layerId) != Acad::eOk)
		{
			acutPrintf(_T("\n Error:- Failed to create layer USER\n"));
			//return;
		}

		// This is not always needed, but a call to 'applyCurDwgLayerTableChanges()'
		// will synchronize the newly created layer table change with the 
		// rest of the current DWG database.

		//2. After the layer table changes, call the 
		//ObjectARX global function applyCurDwgLayerTableChanges().
		// This function will force AutoCAD to update itself 
		// to use any changes made to any layer table records 
		// in the drawing currently in the AutoCAD editor.
		//
		applyCurDwgLayerTableChanges();

		acutPrintf(_T("\nLayer USER successfully created.\n"));

		if (createBlockRecord(_T("EMPLOYEE")) != Acad::eOk)
			acutPrintf(_T("\nFailed to create block record EMPLOYEE\n"));
		else
			acutPrintf(_T("\nSuccessfully created block record EMPLOYEE\n"));
	}

	static void AdkLesson6_SETLAYER(void)
	{
		//1. Open the block table of the current working database
		Acad::ErrorStatus es;

		AcDbBlockTable* pBlockTable;

		es = acdbHostApplicationServices()->workingDatabase()->getBlockTable(pBlockTable, AcDb::kForRead);
		if (es != Acad::eOk)
		{
			acutPrintf(_T("\nFailed to open the Block Table"));
			return;
		}

		//2. Get the MODEL SPACE block table record 
		//(AcDbBlockTable::getAt(), ACDB_MODEL_SPACE ) 
		AcDbBlockTableRecord* pBTRec;
		es = pBlockTable->getAt(ACDB_MODEL_SPACE, pBTRec, AcDb::kForWrite);
		if (es != Acad::eOk)
		{
			acutPrintf(_T("Failed to Get the MODEL SPACE block table record"));
			pBlockTable->close();
			return;
		}
		pBlockTable->close();

		// 3. Obtain a block table record iterator 
		// (AcDbBlockTableRecordIterator, AcDbBlockTableRecord::newIterator()) 
		// to iterate through the MODEL SPACE block table record. 

		AcDbBlockTableRecordIterator* pBTItr;
		if ((es = pBTRec->newIterator(pBTItr)) != Acad::eOk)
		{
			acutPrintf(_T("\nFailed to create block table record iterator"));
			pBTRec->close();
			return;
		}

		// 4. Iterate through the MODEL_SPACE 
		// (AcDbBlockTableRecordIterator::start(), 
		// AcDbBlockTableRecordIterator::done(), 
		// AcDbBlockTableRecordIterator::step()). 

		AcDbEntity* pEnt;
		for (pBTItr->start(); !pBTItr->done(); pBTItr->step())
		{
			//5. To open objects for read or write operations 
			// use acdbOpenObject().
			//6. Obtain the entity(AcDbBlockTableRecordIterator::getEntity()).

			if ((es = pBTItr->getEntity(pEnt, AcDb::kForRead)) != Acad::eOk)
			{
				acutPrintf(_T("\nFailed to open entity through iterator"));
				continue;
			}
			//7. Check if the entity is a block reference
			// (pEnt->isA() != AcDbBlockReference::desc()).
			if (pEnt->isA() != AcDbBlockReference::desc())
			{
				pEnt->close();
				continue;
			}

			//8. Obtain the block table record of the reference
			// (AcDbBlockReference::blockTableRecord()) and 
			// check if the block table record's name is "EMPLOYEE". 

			TCHAR* blockName;
			AcDbBlockTableRecord* pCurEntBlock;
			AcDbObjectId blockId = (AcDbBlockReference::cast(pEnt))->blockTableRecord();
			if (acdbOpenObject((AcDbObject*&)pCurEntBlock, blockId, AcDb::kForRead) == Acad::eOk)
			{
				pCurEntBlock->getName(blockName);
				if (_tcscmp(blockName, _T("EMPLOYEE")) == 0)
				{
					if (pEnt->upgradeOpen() == Acad::eOk)
					{
						//9. Change the layer(setLayer())

						pEnt->setLayer(_T("USER"));
					}
				}
				pCurEntBlock->close();
				acdbFree(blockName);
			}

			//10.Don't forget to close any objects you opened 
			//   and delete the iterator ! 
			pEnt->close();

		}
		delete pBTItr;
		pBTRec->close();

	}
	// ---------myCode------------


	//---my code---begin---for Lesson6---
	static void AdkLesson6_ADDDETAIL(void)
	{
		//1. Let the user select a block reference(acedEntSel()).
		ads_name empName;
		ads_point pt;
		if (acedEntSel(_T("Select Employee block: "), empName, pt) != RTNORM)
		{
			acutPrintf(_T("\nEmp block ref not selected. Abort!!\n"));
			return;
		}

		//1.1.Convert the ads_name to an AcDbObjectId(acdbGetObjectId()).
		AcDbObjectId objId;
		if (acdbGetObjectId(objId, empName) != Acad::eOk)
		{
			acutPrintf(_T("\nFailed to Convert the ads_name to an AcDbObjectId...Aborting!!\n"));
			return;
		}

		//1.2.Open the object(acdbOpenAcDbObject()).
		AcDbObject* pObj;
		if (acdbOpenAcDbObject(pObj, objId, AcDb::kForWrite) != Acad::eOk)
		{
			acutPrintf(_T("\nFailed to Open the object ...Aborting!!\n"));
			return;
		}

		//1.3.Check with the isKindOf() function that the user has selected a 
		//block reference(AcDbBlockReference::desc())
		if (!pObj->isKindOf(AcDbBlockReference::desc()))
		{
			//1.4.Return if it is not a block reference.

			acutPrintf(_T("\nThis is not a block reference.\n"));
			pObj->close();
			return;
		}


		//2. Input employee data for employee ID; employee Cube; employee first name; 
			//employee last name(acedGetInt(), acedGetString()).
		int eID, eCubNum;
		TCHAR eFName[100], eLName[100];
		if (acedGetInt(_T("\nEnter Employee ID: "), &eID) != RTNORM			//SM:- pass address of eID
			|| acedGetInt(_T("Enter Employee cubicle Number: "), &eCubNum) != RTNORM
			|| acedGetString(0, _T("Enter Employee First Name: "), eFName) != RTNORM
			|| acedGetString(0, _T("Enter Employee Last Name: "), eLName) != RTNORM
			)
		{
			acutPrintf(_T("\nFailed for Input employee data..Aborting!\n"));
			pObj->close();
			return;
		}


		//3. Get the extension dictionary of the EMPLOYEE block reference
			//(AcDbObject::extensionDictionary()).
		if ((objId = pObj->extensionDictionary()) == AcDbObjectId::kNull)
		{
			//4. If the EMPLOYEE block reference does not have an extension dictionary 
			//create one(AcDbObject::createExtensionDictionary()).
			if (pObj->createExtensionDictionary() != Acad::eOk)
			{
				acutPrintf(_T("\nFailed for create extension dictionary..Aborting!\n"));
				pObj->close();
				return;
			}
			objId = pObj->extensionDictionary();
		}

		pObj->close(); // use of block ref object over.

		//5. Open the extension dictionary.If the extension dictionary was 
			//erased previously, then open the erased extension dictionary, 
			//since we can reuse the extension dictionary.
		AcDbDictionary* pExtDict;
		if (acdbOpenAcDbObject((AcDbObject*&)pExtDict, objId, AcDb::kForWrite, Adesk::kTrue) != Acad::eOk) //4th arg is for opening erased obj
		{
			acutPrintf(_T("\nFailed to open ext. dictionary.\n"));
			return;
		}

		//6. If the extension dictionary was erased
			//(AcDbObject::isErased()) unerase it
			//(AcDbObject::erase(Adesk::kFalse)).
		if (pExtDict->isErased())
			pExtDict->erase(Adesk::kFalse);

		//7. Retrieve the "Adk_EMPLOYEE_DICTIONARY" 
			//(AcDbDictionary::getAt()).
		AcDbDictionary* pEmpDict;
		if (pExtDict->getAt(_T("Adk_EMPLOYEE_DICTIONARY"), objId) == Acad::eKeyNotFound)
		{
			//7.1. If the "Adk_EMLOYEE_DICTIONARY" AcDbDictionary does not 
			//exist, create an "Adk_EMPLOYEE_DICTIONARY" AcDbDictionary 
			//and add it to the EMPLOYEE block reference extension dictionary.
			pEmpDict = new AcDbDictionary;
			Acad::ErrorStatus es;
			if ((es = pExtDict->setAt(_T("Adk_EMPLOYEE_DICTIONARY"), pEmpDict, objId)) != Acad::eOk)
			{
				acutPrintf(_T("\nFailed to create and add Adk_EMPLOYEE_DICTIONARY AcDbDictionary .\n"));
				pExtDict->close();
				return;
			}
		}
		else
		{
			//Open our dictionary for write if it is already there
			if (acdbOpenAcDbObject(pObj, objId, AcDb::kForWrite) != Acad::eOk)
			{
				pExtDict->close();
				acutPrintf(_T("\nFailed to open the 'Employee' Adk_EMPLOYEE_DICTIONARY dictionary."));
				return;
			}

			// Check if someone has else has created an entry with our name
			// that is not a dictionary.
			if ((pEmpDict = AcDbDictionary::cast(pObj)) == NULL)
			{
				pObj->close();
				pExtDict->close();
				acutPrintf(_T("\nThe entry is not a dictionary"));
				return;
			}
		}

		pExtDict->close(); //Ext Dict noe required further

		//8. Check to see if an AdkEmployeeDetails object is already present 
		//in the "Adk_EMPLOYEE_DICTIONARY" 
		//(we store AdkEmployeeDetails objects under the key "DETAILS").
		if (pEmpDict->getAt(_T("DETAILS"), objId) == Acad::eOk)
		{
			//already present
			pEmpDict->close();
			acutPrintf(_T("\nDetails already assign to that 'Employee' object."));
			return;
		}

		//8.1. If an AdkEmployeeDetails object does not exist, create a 
		//new AdkEmployeeDetails objectand set its data.
		AdkEmployeeDetails* pEmployeeDetails = new AdkEmployeeDetails;
		pEmployeeDetails->setID(eID);
		pEmployeeDetails->setCube(eCubNum);
		pEmployeeDetails->setFirstName(eFName);
		pEmployeeDetails->setLastName(eLName);

		//8.2. Add a new AdkEmployeeDetails object under the key 
		//"DETAILS" in the "Adk_EMPLOYEE_DICTIONARY"
		if (pEmpDict->setAt(_T("DETAILS"), pEmployeeDetails, objId) != Acad::eOk)
		{
			delete pEmployeeDetails;
			acutPrintf(_T("\nFailed to add details to that object..."));
			pEmpDict->close();
			return;
		}

		acutPrintf(_T("\nDetails successfully added!"));
		pEmpDict->close();
		pEmployeeDetails->close();
	}


	static void AdkLesson6_LISTDETAILS(void)
	{
		//1. Let the user select a block reference(acedEntSel()).
		ads_name empName;
		ads_point pt;
		if (acedEntSel(_T("\nSelect Employee block: "), empName, pt) != RTNORM)
		{
			acutPrintf(_T("\nEmp block ref not selected. Abort!!\n"));
			return;
		}

		//1.1.Convert the ads_name to an AcDbObjectId(acdbGetObjectId()).
		AcDbObjectId objId;
		if (acdbGetObjectId(objId, empName) != Acad::eOk)
		{
			acutPrintf(_T("\nFailed to Convert the ads_name to an AcDbObjectId...Aborting!!\n"));
			return;
		}

		//1.2.Open the object(acdbOpenAcDbObject()).
		AcDbObject* pObj;
		if (acdbOpenAcDbObject(pObj, objId, AcDb::kForWrite) != Acad::eOk)
		{
			acutPrintf(_T("\nFailed to Open the object ...Aborting!!\n"));
			return;
		}

		//1.3.Check with the isKindOf() function that the user has selected a 
		//block reference(AcDbBlockReference::desc())
		if (!pObj->isKindOf(AcDbBlockReference::desc()))
		{
			//1.4.Return if it is not a block reference.

			acutPrintf(_T("\nThis is not a block reference.\n"));
			pObj->close();
			return;
		}


		//	2. Retrieve the extension dictionary of the block reference.If there is none return. (AcDbObject::extensionDictionary()).
		if ((objId = pObj->extensionDictionary()) == AcDbObjectId::kNull)
		{
			acutPrintf(_T("\nFailed for fetch extension dictionary..Aborting!\n"));
			pObj->close();
			return;
		}

		pObj->close(); // use of block ref object over.


		//	3. Retrieve the "Adk_EMPLOYEE_DICTIONARY" (AcDbDictionary::getAt()).If there is none return.
		AcDbDictionary* pExtDict;
		if (acdbOpenAcDbObject((AcDbObject*&)pExtDict, objId, AcDb::kForRead, Adesk::kTrue) != Acad::eOk) //4th arg is for opening erased obj
		{
			acutPrintf(_T("\nFailed to open ext. dictionary.\n"));
			return;
		}

		AcDbDictionary* pEmpDict;
		if (pExtDict->getAt(_T("Adk_EMPLOYEE_DICTIONARY"), objId) == Acad::eKeyNotFound)
		{
			acutPrintf(_T("\nFailed to find Adk_EMPLOYEE_DICTIONARY AcDbDictionary .\n"));
			pExtDict->close();
			return;
		}
		else
		{
			//Open our dictionary for read if it is already there
			if (acdbOpenAcDbObject(pObj, objId, AcDb::kForWrite) != Acad::eOk)
			{
				pExtDict->close();
				acutPrintf(_T("\nFailed to open the 'Employee' Adk_EMPLOYEE_DICTIONARY dictionary."));
				return;
			}

			// Check if someone has else has created an entry with our name
			// that is not a dictionary.
			if ((pEmpDict = AcDbDictionary::cast(pObj)) == NULL)
			{
				pObj->close();
				pExtDict->close();
				acutPrintf(_T("\nThe entry is not a dictionary"));
				return;
			}
		}

		pExtDict->close(); //Ext Dict noe required further

		//	4. Retrieve the AdkEmployeeDetails object from the "Adk_EMPLOYEE_DICTIONARY" under the "DETAILS" key.
		if (pEmpDict->getAt(_T("DETAILS"), objId) != Acad::eOk)
		{
			pEmpDict->close();
			acutPrintf(_T("\nFailed to fetch the AdkEmployeeDetails object DETAILS... Aborting!!"));
			return;
		}

		if (acdbOpenAcDbObject(pObj, objId, AcDb::kForWrite) != Acad::eOk)
		{
			pEmpDict->close();
			acutPrintf(_T("\nFailed to open the 'Employee' Adk_EMPLOYEE_DICTIONARY dictionary in read mode.."));
			return;
		}

		// Check it is a AdkEmployeeDetails object
		AdkEmployeeDetails* pEmployeeDetails = AdkEmployeeDetails::cast(pObj);
		if (pEmployeeDetails == NULL) {
			acutPrintf(_T("\nNo details found!."));
			pObj->close();
			pEmpDict->close();
			return;
		}

		//	5. Retrieve the AdkEmployeeDetails object data and print the details.
		// And display details
		Adesk::Int32 i;
		pEmployeeDetails->iD(i);
		acutPrintf(_T("\n*Employee's ID: %d\n"), i);
		pEmployeeDetails->cube(i);
		acutPrintf(_T("*Employee's cube number: %d\n"), i);
		TCHAR* st = NULL;
		pEmployeeDetails->firstName(st);
		acutPrintf(_T("*Employee's first name: %s\n"), st);
		delete[] st;
		pEmployeeDetails->lastName(st);
		acutPrintf(_T("*Employee's last name: %s\n"), st);
		delete[] st;

		pObj->close();
		pEmpDict->close();
	}


	static void AdkLesson6_REMOVEDETAIL(void)
	{
		//1. Let the user select a block reference(acedEntSel()).
		ads_name empName;
		ads_point pt;
		if (acedEntSel(_T("Select Employee block: "), empName, pt) != RTNORM)
		{
			acutPrintf(_T("Emp block ref not selected. Abort!!\n"));
			return;
		}

		//1.1.Convert the ads_name to an AcDbObjectId(acdbGetObjectId()).
		AcDbObjectId objId;
		if (acdbGetObjectId(objId, empName) != Acad::eOk)
		{
			acutPrintf(_T("Failed to Convert the ads_name to an AcDbObjectId...Aborting!!\n"));
			return;
		}

		//1.2.Open the object(acdbOpenAcDbObject()).
		AcDbObject* pObj;
		if (acdbOpenAcDbObject(pObj, objId, AcDb::kForWrite) != Acad::eOk)
		{
			acutPrintf(_T("Failed to Open the block ref object for write...Aborting!!\n"));
			return;
		}

		//1.3.Check with the isKindOf() function that the user has selected a 
		//block reference(AcDbBlockReference::desc())
		if (!pObj->isKindOf(AcDbBlockReference::desc()))
		{
			//1.4.Return if it is not a block reference.

			acutPrintf(_T("This is not a block reference.\n"));
			pObj->close();
			return;
		}


		//	2. Retrieve the extension dictionary of the block reference.If there is none return. (AcDbObject::extensionDictionary()).
		if ((objId = pObj->extensionDictionary()) == AcDbObjectId::kNull)
		{
			acutPrintf(_T("Failed for fetch extension dictionary..Aborting!\n"));
			pObj->close();
			return;
		}

		pObj->close(); // use of block ref object over.


		//	3. Retrieve the "Adk_EMPLOYEE_DICTIONARY" (AcDbDictionary::getAt()).If there is none return.
		AcDbDictionary* pExtDict;
		if (acdbOpenAcDbObject((AcDbObject*&)pExtDict, objId, AcDb::kForWrite, Adesk::kTrue) != Acad::eOk) //4th arg is for opening erased obj
		{
			acutPrintf(_T("Failed to open ext. dictionary in write mode.\n"));
			return;
		}

		AcDbDictionary* pEmpDict;
		if (pExtDict->getAt(_T("Adk_EMPLOYEE_DICTIONARY"), objId) == Acad::eKeyNotFound)
		{
			acutPrintf(_T("Failed to find Adk_EMPLOYEE_DICTIONARY AcDbDictionary .\n"));
			pExtDict->close();
			return;
		}
		else
		{
			//Open our dictionary for read if it is already there
			if (acdbOpenAcDbObject(pObj, objId, AcDb::kForWrite) != Acad::eOk)
			{
				pExtDict->close();
				acutPrintf(_T("\nFailed to open the 'Employee' Adk_EMPLOYEE_DICTIONARY dictionary in write mode."));
				return;
			}

			// Check if someone has else has created an entry with our name
			// that is not a dictionary.
			if ((pEmpDict = AcDbDictionary::cast(pObj)) == NULL)
			{
				pObj->close();
				pExtDict->close();
				acutPrintf(_T("\nThe entry is not a dictionary"));
				return;
			}
		}

		//pExtDict->close(); //Ext Dict noe required further

		//	4. Retrieve the AdkEmployeeDetails object from the "Adk_EMPLOYEE_DICTIONARY" under the "DETAILS" key.
		if (pEmpDict->getAt(_T("DETAILS"), objId) != Acad::eOk)
		{
			pEmpDict->close();
			pExtDict->close();
			acutPrintf(_T("\nFailed to fetch the AdkEmployeeDetails object DETAILS... Aborting!!"));
			return;
		}

		if (acdbOpenAcDbObject(pObj, objId, AcDb::kForWrite) != Acad::eOk)
		{
			pEmpDict->close();
			pExtDict->close();
			acutPrintf(_T("\nFailed to open the 'Employee' Adk_EMPLOYEE_DICTIONARY dictionary in write mode.."));
			return;
		}

		//5. Erase the AdkEmployeeDetails object (AcDbObject::erase()). 
		pObj->erase();
		acutPrintf(_T("\nEmployee details deleted successfully !!"));

		pObj->close();


		//6. Erase the dictionaries if they contains no more entries. (AcDbDictionary::numEntries())
		if (pEmpDict->numEntries() == 0)
		{
			pEmpDict->erase();
			acutPrintf(_T("\nNo more entries.. Adk_EMPLOYEE_DICTIONARY deleted successfully !!"));
		}
		pEmpDict->close();

		if (pExtDict->numEntries() == 0)
		{
			pExtDict->erase();
			acutPrintf(_T("\nNo more entries.. Extension dictionary deleted successfully !!"));
		}
		pExtDict->close();


	}

	//---my code---end---for Lesson6---

} ;

//-----------------------------------------------------------------------------
IMPLEMENT_ARX_ENTRYPOINT(CLesson6App)

ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkMyGroup, MyCommand, MyCommandLocal, ACRX_CMD_MODAL, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkMyGroup, MyPickFirst, MyPickFirstLocal, ACRX_CMD_MODAL | ACRX_CMD_USEPICKSET, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkMyGroup, MySessionCmd, MySessionCmdLocal, ACRX_CMD_MODAL | ACRX_CMD_SESSION, NULL)
ACED_ADSSYMBOL_ENTRY_AUTO(CLesson6App, MyLispFunction, false)

ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkLesson6, _CREATE, CREATE, ACRX_CMD_TRANSPARENT, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkLesson6, _SETLAYER, SETLAYER, ACRX_CMD_TRANSPARENT, NULL)

ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkLesson6, _ADDDETAIL, ADDDETAIL, ACRX_CMD_TRANSPARENT, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkLesson6, _LISTDETAILS, LISTDETAILS, ACRX_CMD_TRANSPARENT, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson6App, AdkLesson6, _REMOVEDETAIL, REMOVEDETAIL, ACRX_CMD_TRANSPARENT, NULL)