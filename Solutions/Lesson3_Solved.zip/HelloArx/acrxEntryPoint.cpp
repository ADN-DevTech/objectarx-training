﻿// (C) Copyright 2002-2012 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- acrxEntryPoint.cpp
//-----------------------------------------------------------------------------
#include "StdAfx.h"
#include "resource.h"
#include <tchar.h>  // for _tcscmp used in AdkMyGroupMyInput's keyword comparison

//-----------------------------------------------------------------------------
#define szRDS _RXST("Adk")

//-----------------------------------------------------------------------------
//----- ObjectARX EntryPoint
class CHelloArxApp : public AcRxArxApp {

public:
	CHelloArxApp () : AcRxArxApp () {}

	virtual AcRx::AppRetCode On_kInitAppMsg (void *pkt) {
		// TODO: Load dependencies here

		// You *must* call On_kInitAppMsg here
		AcRx::AppRetCode retCode =AcRxArxApp::On_kInitAppMsg (pkt) ;
		
		// TODO: Add your initialization code here

		return (retCode) ;
	}

	virtual AcRx::AppRetCode On_kUnloadAppMsg (void *pkt) {
		// TODO: Add your code here

		// You *must* call On_kUnloadAppMsg here
		AcRx::AppRetCode retCode =AcRxArxApp::On_kUnloadAppMsg (pkt) ;

		// TODO: Unload dependencies here

		return (retCode) ;
	}

	virtual void RegisterServerComponents () {
	}
	
	// The ACED_ARXCOMMAND_ENTRY_AUTO macro can be applied to any static member 
	// function of the CHelloArxApp class.
	// The function should take no arguments and return nothing.
	//
	// NOTE: ACED_ARXCOMMAND_ENTRY_AUTO has overloads where you can provide resourceid and
	// have arguments to define context and command mechanism.
	
	// ACED_ARXCOMMAND_ENTRY_AUTO(classname, group, globCmd, locCmd, cmdFlags, UIContext)
	// ACED_ARXCOMMAND_ENTRYBYID_AUTO(classname, group, globCmd, locCmdId, cmdFlags, UIContext)
	// only differs that it creates a localized name using a string in the resource file
	//   locCmdId - resource ID for localized command

	// Modal Command with localized name
	// ACED_ARXCOMMAND_ENTRY_AUTO(CHelloArxApp, AdkMyGroup, MyCommand, MyCommandLocal, ACRX_CMD_MODAL)
	static void AdkMyGroupMyCommand () {
		acutPrintf(ACRX_T("\nHello from HelloArx -- this is all from ClaudeCode. Beep boop, I compile CAD plugins now.\n"));
	}

	// Modal Command with pickfirst selection
	// ACED_ARXCOMMAND_ENTRY_AUTO(CHelloArxApp, AdkMyGroup, MyPickFirst, MyPickFirstLocal, ACRX_CMD_MODAL | ACRX_CMD_USEPICKSET)
	static void AdkMyGroupMyPickFirst () {
		ads_name result ;
		int iRet =acedSSGet (ACRX_T("_I"), NULL, NULL, NULL, result) ;
		if ( iRet == RTNORM )
		{
			// There are selected entities
			// Put your command using pickfirst set code here
		}
		else
		{
			// There are no selected entities
			// Put your command code here
		}
	}

	// Application Session Command with localized name
	// ACED_ARXCOMMAND_ENTRY_AUTO(CHelloArxApp, AdkMyGroup, MySessionCmd, MySessionCmdLocal, ACRX_CMD_MODAL | ACRX_CMD_SESSION)
	static void AdkMyGroupMySessionCmd () {
		// Put your command code here
	}

	// MYINPUT -- demonstrates acedGetInt/acedGetReal input with rules, keywords, and Esc handling.
	// ACED_ARXCOMMAND_ENTRY_AUTO(CHelloArxApp, AdkMyGroup, MyInput, MyInput, ACRX_CMD_MODAL)
	static void AdkMyGroupMyInput()
	{
		// (a) Integer input — reject negative AND zero.
		//     acedInitGet rules apply to the very next acedGetXxx call.
		int iVal = 0;
		acedInitGet(RSG_NONEG | RSG_NOZERO, NULL);
		int rc = acedGetInt(ACRX_T("\nEnter a positive integer: "), &iVal);
		if (rc == RTCAN) { acutPrintf(ACRX_T("\nCancelled.")); return; }  // (c) Esc
		if (rc != RTNORM) { acutPrintf(ACRX_T("\nInvalid input.")); return; }

		// (b) Real input with keywords PI/A/B/C, defaulting to C on Enter.
		double dVal = 12.0;                       // default = C
		acedInitGet(0, ACRX_T("PI A B C"));         // register the keywords
		rc = acedGetReal(ACRX_T("\nEnter a real value or [PI/A/B/C] <C>: "), &dVal);

		if (rc == RTCAN) {                         // (c) Esc
			acutPrintf(ACRX_T("\nCancelled."));
			return;
		}
		else if (rc == RTNONE) {                   // Enter pressed -> default C
			dVal = 12.0;
		}
		else if (rc == RTKWORD) {                  // a keyword was typed
			ACHAR kw[512];
			if (acedGetInput(kw) == RTNORM) {
				if (_tcscmp(kw, ACRX_T("PI")) == 0) dVal = 3.14;
				else if (_tcscmp(kw, ACRX_T("A")) == 0) dVal = 10.0;
				else if (_tcscmp(kw, ACRX_T("B")) == 0) dVal = 11.0;
				else if (_tcscmp(kw, ACRX_T("C")) == 0) dVal = 12.0;
			}
		}
		// rc == RTNORM -> the user typed a number; dVal already holds it.

		// (d) Show the results.
		acutPrintf(ACRX_T("\nInteger = %d, Real = %g"), iVal, dVal);
	}

	// MYSELECT -- demonstrates acedEntSel single-entity selection.
	// ACED_ARXCOMMAND_ENTRY_AUTO(CHelloArxApp, AdkMyGroup, MySelect, MySelect, ACRX_CMD_MODAL)
	static void AdkMyGroupMySelect () {
		ads_name  en;
		ads_point pt;
		int rc = acedEntSel(ACRX_T("\nSelect an entity: "), en, pt);

		if (rc == RTCAN)  { acutPrintf(ACRX_T("\nCancelled.")); return; }
		if (rc != RTNORM) { acutPrintf(ACRX_T("\nNo entity selected.")); return; }

		// The Object ID is the first element of the ads_name.
		acutPrintf(_T("\nYou selected entity ID: %ld"), en[0]);
	}

	// The ACED_ADSFUNCTION_ENTRY_AUTO / ACED_ADSCOMMAND_ENTRY_AUTO macros can be applied to any static member 
	// function of the CHelloArxApp class.
	// The function may or may not take arguments and have to return RTNORM, RTERROR, RTCAN, RTFAIL, RTREJ to AutoCAD, but use
	// acedRetNil, acedRetT, acedRetVoid, acedRetInt, acedRetReal, acedRetStr, acedRetPoint, acedRetName, acedRetList, acedRetVal to return
	// a value to the Lisp interpreter.
	//
	// NOTE: ACED_ADSFUNCTION_ENTRY_AUTO / ACED_ADSCOMMAND_ENTRY_AUTO has overloads where you can provide resourceid.
	
	//- ACED_ADSFUNCTION_ENTRY_AUTO(classname, name, regFunc) - this example
	//- ACED_ADSSYMBOL_ENTRYBYID_AUTO(classname, name, nameId, regFunc) - only differs that it creates a localized name using a string in the resource file
	//- ACED_ADSCOMMAND_ENTRY_AUTO(classname, name, regFunc) - a Lisp command (prefix C:)
	//- ACED_ADSCOMMAND_ENTRYBYID_AUTO(classname, name, nameId, regFunc) - only differs that it creates a localized name using a string in the resource file

	// Lisp Function is similar to ARX Command but it creates a lisp 
	// callable function. Many return types are supported not just string
	// or integer.
	// ACED_ADSFUNCTION_ENTRY_AUTO(CHelloArxApp, MyLispFunction, false)
	static int ads_MyLispFunction () {
		//struct resbuf *args =acedGetArgs () ;
		
		// Put your command code here

		//acutRelRb (args) ;
		
		// Return a value to the AutoCAD Lisp Interpreter
		// acedRetNil, acedRetT, acedRetVoid, acedRetInt, acedRetReal, acedRetStr, acedRetPoint, acedRetName, acedRetList, acedRetVal

		return (RTNORM) ;
	}
	
} ;

//-----------------------------------------------------------------------------
IMPLEMENT_ARX_ENTRYPOINT(CHelloArxApp)

ACED_ARXCOMMAND_ENTRY_AUTO(CHelloArxApp, AdkMyGroup, MyCommand, MyCommandLocal, ACRX_CMD_MODAL, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CHelloArxApp, AdkMyGroup, MyPickFirst, MyPickFirstLocal, ACRX_CMD_MODAL | ACRX_CMD_USEPICKSET, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CHelloArxApp, AdkMyGroup, MySessionCmd, MySessionCmdLocal, ACRX_CMD_MODAL | ACRX_CMD_SESSION, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CHelloArxApp, AdkMyGroup, MyInput, MyInput, ACRX_CMD_MODAL, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CHelloArxApp, AdkMyGroup, MySelect, MySelect, ACRX_CMD_MODAL, NULL)
ACED_ADSSYMBOL_ENTRY_AUTO(CHelloArxApp, MyLispFunction, false)

