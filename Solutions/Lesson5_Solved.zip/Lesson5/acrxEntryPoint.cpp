﻿// (C) Copyright 2002-2012 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- acrxEntryPoint.cpp
//-----------------------------------------------------------------------------
#include "StdAfx.h"
#include "resource.h"
#include "tchar.h"

//-----------------------------------------------------------------------------
#define szRDS _RXST("Adk")

//-----------------------------------------------------------------------------
//----- ObjectARX EntryPoint
class CLesson5App : public AcRxArxApp {

public:
	CLesson5App () : AcRxArxApp () {}

	virtual AcRx::AppRetCode On_kInitAppMsg (void *pkt) {
		// TODO: Load dependencies here

		// You *must* call On_kInitAppMsg here
		AcRx::AppRetCode retCode =AcRxArxApp::On_kInitAppMsg (pkt) ;
		
		// TODO: Add your initialization code here

		return (retCode) ;
	}

	virtual AcRx::AppRetCode On_kUnloadAppMsg (void *pkt) {
		// TODO: Add your code here

		// You *must* call On_kUnloadAppMsg here
		AcRx::AppRetCode retCode =AcRxArxApp::On_kUnloadAppMsg (pkt) ;

		// TODO: Unload dependencies here

		return (retCode) ;
	}

	virtual void RegisterServerComponents () {
	}
	
	// The ACED_ARXCOMMAND_ENTRY_AUTO macro can be applied to any static member 
	// function of the CLesson5App class.
	// The function should take no arguments and return nothing.
	//
	// NOTE: ACED_ARXCOMMAND_ENTRY_AUTO has overloads where you can provide resourceid and
	// have arguments to define context and command mechanism.
	
	// ACED_ARXCOMMAND_ENTRY_AUTO(classname, group, globCmd, locCmd, cmdFlags, UIContext)
	// ACED_ARXCOMMAND_ENTRYBYID_AUTO(classname, group, globCmd, locCmdId, cmdFlags, UIContext)
	// only differs that it creates a localized name using a string in the resource file
	//   locCmdId - resource ID for localized command

	// Modal Command with localized name
	// ACED_ARXCOMMAND_ENTRY_AUTO(CLesson5App, AdkMyGroup, MyCommand, MyCommandLocal, ACRX_CMD_MODAL)
	static void AdkMyGroupMyCommand () {
		// Put your command code here

	}

	// Modal Command with pickfirst selection
	// ACED_ARXCOMMAND_ENTRY_AUTO(CLesson5App, AdkMyGroup, MyPickFirst, MyPickFirstLocal, ACRX_CMD_MODAL | ACRX_CMD_USEPICKSET)
	static void AdkMyGroupMyPickFirst () {
		ads_name result ;
		int iRet =acedSSGet (ACRX_T("_I"), NULL, NULL, NULL, result) ;
		if ( iRet == RTNORM )
		{
			// There are selected entities
			// Put your command using pickfirst set code here
		}
		else
		{
			// There are no selected entities
			// Put your command code here
		}
	}

	// Application Session Command with localized name
	// ACED_ARXCOMMAND_ENTRY_AUTO(CLesson5App, AdkMyGroup, MySessionCmd, MySessionCmdLocal, ACRX_CMD_MODAL | ACRX_CMD_SESSION)
	static void AdkMyGroupMySessionCmd () {
		// Put your command code here
	}

	// The ACED_ADSFUNCTION_ENTRY_AUTO / ACED_ADSCOMMAND_ENTRY_AUTO macros can be applied to any static member 
	// function of the CLesson5App class.
	// The function may or may not take arguments and have to return RTNORM, RTERROR, RTCAN, RTFAIL, RTREJ to AutoCAD, but use
	// acedRetNil, acedRetT, acedRetVoid, acedRetInt, acedRetReal, acedRetStr, acedRetPoint, acedRetName, acedRetList, acedRetVal to return
	// a value to the Lisp interpreter.
	//
	// NOTE: ACED_ADSFUNCTION_ENTRY_AUTO / ACED_ADSCOMMAND_ENTRY_AUTO has overloads where you can provide resourceid.
	
	//- ACED_ADSFUNCTION_ENTRY_AUTO(classname, name, regFunc) - this example
	//- ACED_ADSSYMBOL_ENTRYBYID_AUTO(classname, name, nameId, regFunc) - only differs that it creates a localized name using a string in the resource file
	//- ACED_ADSCOMMAND_ENTRY_AUTO(classname, name, regFunc) - a Lisp command (prefix C:)
	//- ACED_ADSCOMMAND_ENTRYBYID_AUTO(classname, name, nameId, regFunc) - only differs that it creates a localized name using a string in the resource file

	// Lisp Function is similar to ARX Command but it creates a lisp 
	// callable function. Many return types are supported not just string
	// or integer.
	// ACED_ADSFUNCTION_ENTRY_AUTO(CLesson5App, MyLispFunction, false)
	static int ads_MyLispFunction () {
		//struct resbuf *args =acedGetArgs () ;
		
		// Put your command code here

		//acutRelRb (args) ;
		
		// Return a value to the AutoCAD Lisp Interpreter
		// acedRetNil, acedRetT, acedRetVoid, acedRetInt, acedRetReal, acedRetStr, acedRetPoint, acedRetName, acedRetList, acedRetVal

		return (RTNORM) ;
	}

	// Commands for the AdkLesson5 group referenced by the
	// ACED_ARXCOMMAND_ENTRY_AUTO macros below.


	static void AdkLesson5_ADDENTRY ()
	{
		TCHAR empName[100];
		if (acedGetString(0, _T("Enter Employee name: "), empName) != RTNORM)
		{
			acutPrintf(_T("Failed to get emp name. Aborted!"));
			return;
		}

		//Get NOD
		AcDbDictionary* pNOD;
		if (acdbHostApplicationServices()->workingDatabase()->getNamedObjectsDictionary(pNOD, AcDb::kForRead) != Acad::eOk)
		{
			acutPrintf(_T("Failed to open NOD. Aborted!"));
			return;
		}

		//check for existing dic
		AcDbObjectId idDict;
		AcDbDictionary* pEmpDict = NULL;

		if (pNOD->getAt(_T("ADSK_EMPLOYEE_DICTIONARY"), idDict) == Acad::eKeyNotFound)
		{
			//create key
			if (pNOD->upgradeOpen() != Acad::eOk)
			{
				acutPrintf(_T("\nCannot open NOD for Write!"));
				pNOD->close();
				return;
			}

			pEmpDict = new AcDbDictionary;

			if (pNOD->setAt(_T("ADSK_EMPLOYEE_DICTIONARY"), pEmpDict, idDict) != Acad::eOk)
			{
				acutPrintf(_T("\nCannot add our dictionary in the AutoCAD NOD!"));
				// Clean-up memory and abort
				delete pEmpDict;
				pNOD->close();
				return;
			}
		}
		else
		{
			//if Dict already found to be existing
			acutPrintf(_T("\nDictionary found in the AutoCAD NOD! Adding Employee Record..."));

			AcDbObject* pEmpObj;
			if (acdbOpenAcDbObject(pEmpObj, idDict, AcDb::kForWrite) != Acad::eOk)
			{
				acutPrintf(_T("\nCannot open the Emp object for write."));
				pNOD->close();
				return;
			}

			// Check if someone has else has created an entry with our name
			// that is not a dictionary. This should never happen as long as
			// I use the registered developer RDS prefix.
			if ((pEmpDict = AcDbDictionary::cast(pEmpObj)) == NULL)
			{
				acutPrintf(_T("\nEntry found in the NOD, but it is not a dictionary."));
				pEmpObj->close();
				pNOD->close();
				return;
			}
		}
		pNOD->close();

		// 5. Check if the name of the employee is already in the "ADSK_EMPLOYEE_DICTIONARY" dictionary. 
		if (pEmpDict->getAt(empName, idDict) == Acad::eOk)
		{
			acutPrintf(_T("\nThis employee is already registered."));
			pEmpDict->close();
			return;
		}

		//6. If the employee dictionary is not present, then create a 
		// new AcDbXrecord and add it to the "ADSK_EMPLOYEE_DICTIONARY" 
		// (AcDbDictionary::setAt()). 

		AcDbXrecord* pEmpXRec = new AcDbXrecord;
		if (pEmpDict->setAt(empName, pEmpXRec, idDict) != Acad::eOk)
		{
			acutPrintf(_T("\nFailed to add the new employee in the dictionary."));
			delete pEmpXRec;
			pEmpDict->close();
			return;
		}
		else
			acutPrintf(_T("\nEmployee Record Added!"));


		pEmpXRec->close();
		pEmpDict->close();
	}

	static void AdkLesson5_LISTENTRIES()
	{
		//1. Get the Named Objects Dictionary from the current working database 
		//(AcDbDictionary, AcDbDatabase::getNamedObjectsDictionary()). 
		AcDbDictionary* pNOD;
		if (acdbHostApplicationServices()->workingDatabase()->getNamedObjectsDictionary(pNOD, AcDb::kForRead) != Acad::eOk)
		{
			acutPrintf(_T("Failed to Get the Named Objects Dictionary from the current working database"));
			return;
		}

		//2. Get the "ADSK_EMPLOYEE_DICTIONARY" dictionary
		//(AcDbDictionary::getAt()).
		AcDbObjectId idObj;
		AcDbObject* pObj;

		if (pNOD->getAt(_T("ADSK_EMPLOYEE_DICTIONARY"), idObj) != Acad::eOk)
		{
			acutPrintf(_T("Failed to fetch ADSK_EMPLOYEE_DICTIONARY dictionary"));
			pNOD->close();
			return;
		}

		//Open Emp Dict in read mode***
		if (acdbOpenAcDbObject(pObj, idObj, AcDb::kForRead) != Acad::eOk)
		{
			acutPrintf(_T("Failed to Open Emp Dict in read mode"));
			pNOD->close();
			return;
		}

		// Check if someone has else has created an entry with our name
		// that is not a dictionary. This should never happen as long as
		// I use the registered developer RDS prefix. ???????????
		AcDbDictionary* pEmployeeDict;
		if ((pEmployeeDict = AcDbDictionary::cast(pObj)) == NULL) {
			acutPrintf(_T("\nEntry found in the NOD, but it is not a dictionary."));
			pObj->close();
			pNOD->close();
			return;
		}
		pNOD->close();


		//3. Iterate through the "ADSK_EMPLOYEE_DICTIONARY" and print out 
		//the dictionary keys(employee names).
		//3.1. Create a new iterator
		//(AcDbDictionary::newIterator(), AcDbDictionaryIterator).
		AcDbDictionaryIterator* pDictItr;
		if ((pDictItr = pEmployeeDict->newIterator()) != NULL)
		{
			//3.2. Iterate through the "ADSK_EMPLOYEE_DICTIONARY" 
			//(AcDbDictionaryIterator::done(), AcDbDictionaryIterator::next()).
			for (int i = 1; !pDictItr->done(); pDictItr->next(), i++)
			{
				//3.3. Print the dictionary key
				//(AcDbDictionaryIterator::name()).
				acutPrintf(_T("Employee Record at index <%d> is %s\n"), i, pDictItr->name());
			}

			//4. Delete the iterator and don't forget to close opened objects. 
			delete pDictItr;
		}
		pEmployeeDict->close();
	}

	static void AdkLesson5_REMOVEENTRY ()
	{
		//1. Get an employee name from the user (acedGetString()) to remove. 
		TCHAR empName[100];
		if (acedGetString(0, _T("Enter Employee Name to delete Record: "), empName) != RTNORM)
		{
			acutPrintf(_T("Unable to get name. Abort!"));
			return;
		}

		//2. Get the Named Objects Dictionary from the current working database
		// (AcDbDictionary, AcDbDatabase::getNamedObjectsDictionary()).
		AcDbDictionary* pNOD;
		if (acdbHostApplicationServices()->workingDatabase()->getNamedObjectsDictionary(pNOD, AcDb::kForRead) != Acad::eOk)
		{
			acutPrintf(_T("Failed to Get the Named Objects Dictionary from the current working database. Abort!!"));
			return;
		}

		//3. Get the "ADSK_EMPLOYEE_DICTIONARY" dictionary
		// (AcDbDictionary::getAt()).
		AcDbObjectId idObj;
		AcDbObject* pObj;
		if (pNOD->getAt(_T("ADSK_EMPLOYEE_DICTIONARY"), idObj) != Acad::eOk)
		{
			acutPrintf(_T("Failed to Get/ No existing \"ADSK_EMPLOYEE_DICTIONARY\" dictionary. Abort!!"));
			pNOD->close();
			return;
		}

		//*****Open the EmpDict obj for reading
		if (acdbOpenAcDbObject(pObj, idObj, AcDb::kForRead) != Acad::eOk)
		{
			acutPrintf(_T("Failed to Open the EmpDict obj for reading. Aborting!!"));
			pNOD->close();
			return;
		}
		// ******Check if someone has else has created an entry with our name
		// that is not a dictionary. This should never happen as long as
		// I use the registered developer RDS prefix.
		AcDbDictionary* pEmployeeDict;
		if ((pEmployeeDict = AcDbDictionary::cast(pObj)) == NULL) {
			acutPrintf(_T("\nEntry found in the NOD, but it is not a dictionary."));
			pObj->close();
			pNOD->close();
			return;
		}
		pNOD->close();

		//4. Get the AcDbXrecord entry with the given employee name.
		if (pEmployeeDict->getAt(empName, idObj) != Acad::eOk)
		{
			acutPrintf(_T("Employee's entry not found!"));
			pEmployeeDict->close();
			return;
		}
		pEmployeeDict->close();

		//5. If the employee entry exists, open it for write and then 
		// erase it(AcDbObject::erase()).
		if (acdbOpenAcDbObject(pObj, idObj, AcDb::kForWrite) != Acad::eOk)
		{
			acutPrintf(_T("Failed to Open the Emp XRecord obj for writing. Aborting!!"));
			pNOD->close();
			return;
		}

		pObj->erase();
		acutPrintf(_T("Employee record for %s deleted!!"), empName);

		pObj->close();
	}
	
} ;

//-----------------------------------------------------------------------------
IMPLEMENT_ARX_ENTRYPOINT(CLesson5App)

ACED_ARXCOMMAND_ENTRY_AUTO(CLesson5App, AdkMyGroup, MyCommand, MyCommandLocal, ACRX_CMD_MODAL, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson5App, AdkMyGroup, MyPickFirst, MyPickFirstLocal, ACRX_CMD_MODAL | ACRX_CMD_USEPICKSET, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson5App, AdkMyGroup, MySessionCmd, MySessionCmdLocal, ACRX_CMD_MODAL | ACRX_CMD_SESSION, NULL)
ACED_ADSSYMBOL_ENTRY_AUTO(CLesson5App, MyLispFunction, false)

ACED_ARXCOMMAND_ENTRY_AUTO(CLesson5App, AdkLesson5, _LISTENTRIES, LISTENTRIES, ACRX_CMD_TRANSPARENT, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson5App, AdkLesson5, _ADDENTRY, ADDENTRY, ACRX_CMD_TRANSPARENT, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson5App, AdkLesson5, _REMOVEENTRY, REMOVEENTRY, ACRX_CMD_TRANSPARENT, NULL)
