#include "pch.h"
#include "tchar.h"
#include <aced.h>
#include <rxregsvc.h>

void initApp();
void unloadApp();
void helloWorld();

void initApp()
{
    // register a command with the AutoCAD command mechanism
    acedRegCmds->addCommand(_T("HELLOWORLD_COMMANDS"),
        _T("Hello"),      // global (untranslated) name
        _T("Bonjour"),    // local (translated) name
        ACRX_CMD_TRANSPARENT,
        helloWorld);      // function to call
}
void unloadApp()
{
    acedRegCmds->removeGroup(_T("HELLOWORLD_COMMANDS"));
}
void helloWorld()
{
    acutPrintf(_T("\nHello World!"));
}

extern "C" AcRx::AppRetCode
acrxEntryPoint(AcRx::AppMsgCode msg, void* pkt)
{
    switch (msg)
    {
    case AcRx::kInitAppMsg:
        acrxDynamicLinker->unlockApplication(pkt);  // allow unloading
        acrxRegisterAppMDIAware(pkt);
        initApp();
        break;
    case AcRx::kUnloadAppMsg:
        unloadApp();
        break;
    default:
        break;
    }
    return AcRx::kRetOK;
}
