﻿// (C) Copyright 2002-2012 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- acrxEntryPoint.cpp
//-----------------------------------------------------------------------------
#include "StdAfx.h"
#include "resource.h"
#include "tchar.h"

//-----------------------------------------------------------------------------
#define szRDS _RXST("Adk")

//-----------------------------------------------------------------------------
//----- ObjectARX EntryPoint
class CLesson7App : public AcRxArxApp {

public:
	CLesson7App () : AcRxArxApp () {}

	virtual AcRx::AppRetCode On_kInitAppMsg (void *pkt) {
		// TODO: Load dependencies here

		// You *must* call On_kInitAppMsg here
		AcRx::AppRetCode retCode =AcRxArxApp::On_kInitAppMsg (pkt) ;
		
		// TODO: Add your initialization code here
		//my code ---begin---
		AcRxObject* pSvc;
		if (!(pSvc = acrxServiceDictionary->at(ADKEMPLOYEE_DBXSERVICE)))
		{
			if (!acrxDynamicLinker->loadModule(ACRX_T("AdkEmployee.dbx"), 0))
			{
				acutPrintf(ACRX_T("\nUnable to load AdkEmployee.dbx. Unloading...\n"));
				return AcRx::kRetError;
			}
		}
		//my code ---end---




		return (retCode) ;
	}

	virtual AcRx::AppRetCode On_kUnloadAppMsg (void *pkt) {
		// TODO: Add your code here

		// You *must* call On_kUnloadAppMsg here
		AcRx::AppRetCode retCode =AcRxArxApp::On_kUnloadAppMsg (pkt) ;

		// TODO: Unload dependencies here

		return (retCode) ;
	}

	virtual void RegisterServerComponents () {
	}
	
	// The ACED_ARXCOMMAND_ENTRY_AUTO macro can be applied to any static member 
	// function of the CLesson7App class.
	// The function should take no arguments and return nothing.
	//
	// NOTE: ACED_ARXCOMMAND_ENTRY_AUTO has overloads where you can provide resourceid and
	// have arguments to define context and command mechanism.
	
	// ACED_ARXCOMMAND_ENTRY_AUTO(classname, group, globCmd, locCmd, cmdFlags, UIContext)
	// ACED_ARXCOMMAND_ENTRYBYID_AUTO(classname, group, globCmd, locCmdId, cmdFlags, UIContext)
	// only differs that it creates a localized name using a string in the resource file
	//   locCmdId - resource ID for localized command

	// Modal Command with localized name
	// ACED_ARXCOMMAND_ENTRY_AUTO(CLesson7App, AdkMyGroup, MyCommand, MyCommandLocal, ACRX_CMD_MODAL)
	static void AdkMyGroupMyCommand () {
		// Put your command code here

	}

	// Modal Command with pickfirst selection
	// ACED_ARXCOMMAND_ENTRY_AUTO(CLesson7App, AdkMyGroup, MyPickFirst, MyPickFirstLocal, ACRX_CMD_MODAL | ACRX_CMD_USEPICKSET)
	static void AdkMyGroupMyPickFirst () {
		ads_name result ;
		int iRet =acedSSGet (ACRX_T("_I"), NULL, NULL, NULL, result) ;
		if ( iRet == RTNORM )
		{
			// There are selected entities
			// Put your command using pickfirst set code here
		}
		else
		{
			// There are no selected entities
			// Put your command code here
		}
	}

	// Application Session Command with localized name
	// ACED_ARXCOMMAND_ENTRY_AUTO(CLesson7App, AdkMyGroup, MySessionCmd, MySessionCmdLocal, ACRX_CMD_MODAL | ACRX_CMD_SESSION)
	static void AdkMyGroupMySessionCmd () {
		// Put your command code here
	}

	// The ACED_ADSFUNCTION_ENTRY_AUTO / ACED_ADSCOMMAND_ENTRY_AUTO macros can be applied to any static member 
	// function of the CLesson7App class.
	// The function may or may not take arguments and have to return RTNORM, RTERROR, RTCAN, RTFAIL, RTREJ to AutoCAD, but use
	// acedRetNil, acedRetT, acedRetVoid, acedRetInt, acedRetReal, acedRetStr, acedRetPoint, acedRetName, acedRetList, acedRetVal to return
	// a value to the Lisp interpreter.
	//
	// NOTE: ACED_ADSFUNCTION_ENTRY_AUTO / ACED_ADSCOMMAND_ENTRY_AUTO has overloads where you can provide resourceid.
	
	//- ACED_ADSFUNCTION_ENTRY_AUTO(classname, name, regFunc) - this example
	//- ACED_ADSSYMBOL_ENTRYBYID_AUTO(classname, name, nameId, regFunc) - only differs that it creates a localized name using a string in the resource file
	//- ACED_ADSCOMMAND_ENTRY_AUTO(classname, name, regFunc) - a Lisp command (prefix C:)
	//- ACED_ADSCOMMAND_ENTRYBYID_AUTO(classname, name, nameId, regFunc) - only differs that it creates a localized name using a string in the resource file

	// Lisp Function is similar to ARX Command but it creates a lisp 
	// callable function. Many return types are supported not just string
	// or integer.
	// ACED_ADSFUNCTION_ENTRY_AUTO(CLesson7App, MyLispFunction, false)
	static int ads_MyLispFunction () {
		//struct resbuf *args =acedGetArgs () ;
		
		// Put your command code here

		//acutRelRb (args) ;
		
		// Return a value to the AutoCAD Lisp Interpreter
		// acedRetNil, acedRetT, acedRetVoid, acedRetInt, acedRetReal, acedRetStr, acedRetPoint, acedRetName, acedRetList, acedRetVal

		return (RTNORM) ;
	}



	//my code---begin---
	static void AdkLesson7_CREATEEMPLOYEE(void)
	{
		int eId, eCubNum;
		TCHAR eFName[100], eLName[100];
		AcGePoint3d ePt;

		//1. Input employee data for employee ID; employee cubicle; employee first name; 
		//employee last name(acedGetInt(), acedGetString()) and employee position(acedGetPoint()).
		//NOTE: The function acedGetPoint() returns an ads_point representing the point picked 
		//by the user.To convert an ads_point directly into an AcGePoint3d point use the 
		//global function asDblArray().

		if ((acedGetInt(_T("\nEnter Employee ID: "), &eId) != RTNORM)
			|| (acedGetInt(_T("\nEnter Employee Cubicle: "), &eCubNum) != RTNORM)
			|| (acedGetString(0, _T("\nEnter Employee's First Name: "), eFName) != RTNORM)
			|| (acedGetString(0, _T("\nEnter Employee's Last Name: "), eLName) != RTNORM)
			|| (acedGetPoint(NULL, _T("\nEnter Employee's position: "), asDblArray(ePt)) != RTNORM)
			)
		{
			acutPrintf(_T("Failed to receive Employee Input Data.. Aborting!!"));
			return;
		}

		AcDbBlockTable* pBlockTable;
		if (acdbHostApplicationServices()->workingDatabase()->getBlockTable(pBlockTable, AcDb::kForRead) == Acad::eOk)
		{
			AcDbBlockTableRecord* pBTRec;
			if (pBlockTable->getAt(ACDB_MODEL_SPACE, pBTRec, AcDb::kForWrite) == Acad::eOk)
			{
				//2. Create a new instance of the AdkEmployee entity.
				AdkEmployee* pEmpEnt = new AdkEmployee;

				//3. Set the AdkEmployee data.
				pEmpEnt->setID(eId);
				pEmpEnt->setCube(eCubNum);
				pEmpEnt->setFirstName(eFName);
				pEmpEnt->setLastName(eLName);

				pEmpEnt->setCenter(ePt);

				//4. Add the AdkEmployee entity to the Model Space record.
				AcDbObjectId objId;
				if (pBTRec->appendAcDbEntity(objId, pEmpEnt) == Acad::eOk)
				{
					acutPrintf(_T("Employee Entity successfully appended to MODEL SPACE"));
					pEmpEnt->close();
				}
				else
				{
					acutPrintf(_T("Failed to add Employee Entity to MODEL SPACE"));
					delete pEmpEnt;
				}
				pBTRec->close();
			}
			pBlockTable->close();
		}


	}
	//my code---end---
	
} ;

//-----------------------------------------------------------------------------
IMPLEMENT_ARX_ENTRYPOINT(CLesson7App)

ACED_ARXCOMMAND_ENTRY_AUTO(CLesson7App, AdkMyGroup, MyCommand, MyCommandLocal, ACRX_CMD_MODAL, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson7App, AdkMyGroup, MyPickFirst, MyPickFirstLocal, ACRX_CMD_MODAL | ACRX_CMD_USEPICKSET, NULL)
ACED_ARXCOMMAND_ENTRY_AUTO(CLesson7App, AdkMyGroup, MySessionCmd, MySessionCmdLocal, ACRX_CMD_MODAL | ACRX_CMD_SESSION, NULL)
ACED_ADSSYMBOL_ENTRY_AUTO(CLesson7App, MyLispFunction, false)

ACED_ARXCOMMAND_ENTRY_AUTO(CLesson7App, AdkLesson7, _CREATEEMPLOYEE, CREATEEMPLOYEE, ACRX_CMD_TRANSPARENT, NULL)
